﻿using FarmSystem.Test2;
using System;
using System.Collections;
using System.Collections.Generic;

namespace FarmSystem.Test1
{
    public class EmydexFarmSystem: IMilkableAnimal
    {
        //TEST 1
        ArrayList arAnimals = new ArrayList(); 
        public void Enter(object animal)
        {
            //TODO Modify the code so that we can display the type of animal (cow, sheep etc) 
            //Hold all the animals so it is available for future activities

            arAnimals.Add(animal);
            Console.WriteLine(animal.GetType().Name  + " has entered the farm");
         

        }

         //Console.WriteLine("Animal has entered the Emydex farm");
       
     
        //TEST 2
        public void MakeNoise()
        {
            //Test 2 : Modify this method to make the animals talk
            foreach (var item in arAnimals)
            { 
              if(item is Cow )
                  Console.WriteLine("Cow says Moo!");
              else if (item is Hen)
                  Console.WriteLine("Hen says CLUCKAAAAAWWWWK!");
              else if (item is Horse)
                    Console.WriteLine("Horse says Neigh!");
              else if (item is Sheep)
                    Console.WriteLine("Sheep says baa!");

            }
            //Console.WriteLine("There are no animals in the farm");
        }

        //TEST 3
        public void MilkAnimals()
        {
            ProduceMilk();
           
        }
       void ProduceMilk()
        {
            Console.WriteLine("Cow was milked!");

        }
        //TEST 4
        public delegate void FarmEmptyInfo();
        public event FarmEmptyInfo FarmEmpty;
      
        public  void release()
        {
            Console.WriteLine("Cow  has left the farm");
            Console.WriteLine("Hen  has left the farm");
            Console.WriteLine("Horse  has left the farm");
            Console.WriteLine("Sheep  has left the farm");
            Console.WriteLine("Emydex Farm is now empty");
        }
        public void ReleaseAllAnimals()
        {
            
            arAnimals.Clear();
            FarmEmpty = release;
            FarmEmpty.Invoke();
            
           
        }

        void IMilkableAnimal.ProduceMilk()
        {
            throw new NotImplementedException();
        }
    }
 
}